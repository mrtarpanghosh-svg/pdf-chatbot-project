# 📄 PDF Chatbot (AI-powered)

A simple **PDF Chatbot** project that allows users to upload PDF documents and ask questions.
The chatbot retrieves relevant content from the PDF and generates answers using an LLM.

## 🚀 Features
- Upload and read PDF files
- Text chunking & embeddings
- Semantic search
- Question answering
- GitHub-ready clean structure

## 🛠 Tech Stack
- Python
- LangChain
- FAISS (Vector DB)
- OpenAI / LLM API
- Streamlit (UI)

## 📁 Project Structure
```
pdf-chatbot/
│── app.py
│── requirements.txt
│── README.md
│── utils/
│   ├── pdf_loader.py
│   ├── text_processing.py
│   └── chatbot.py
│── data/
│── .gitignore
```

## ▶️ Run the Project
```bash
pip install -r requirements.txt
streamlit run app.py
```

## 📌 Use Case
- Resume Q&A
- Research paper assistant
- Notes chatbot
