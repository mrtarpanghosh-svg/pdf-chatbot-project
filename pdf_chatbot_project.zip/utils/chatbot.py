from langchain.chains import RetrievalQA
from langchain.llms import OpenAI

def ask_question(vectorstore, question):
    llm = OpenAI()
    qa = RetrievalQA.from_chain_type(
        llm=llm,
        retriever=vectorstore.as_retriever()
    )
    return qa.run(question)
