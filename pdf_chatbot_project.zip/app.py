import streamlit as st
from utils.pdf_loader import load_pdf
from utils.text_processing import create_chunks, create_vectorstore
from utils.chatbot import ask_question

st.set_page_config(page_title="PDF Chatbot")

st.title("📄 PDF Chatbot")

uploaded_file = st.file_uploader("Upload a PDF", type="pdf")

if uploaded_file:
    text = load_pdf(uploaded_file)
    chunks = create_chunks(text)
    vectorstore = create_vectorstore(chunks)

    question = st.text_input("Ask a question from the PDF")

    if question:
        answer = ask_question(vectorstore, question)
        st.write("### Answer")
        st.write(answer)
